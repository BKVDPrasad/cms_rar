from django.contrib import admin
from django.db.migrations.recorder import MigrationRecorder

from app.models import *



admin.site.register(Student)
admin.site.register(EmployeeCarDetails)
admin.site.register(model_or_iterable=Employee, admin_class=None)

# admin.site.register(MigrationRecorder.Migration)

from django.contrib import admin
from django.db.migrations.recorder import MigrationRecorder

from django.contrib import admin
from django.db.migrations.recorder import MigrationRecorder
# from .apps import MigrationsConfig
#
# class MigrationAdmin(admin.ModelAdmin):
#     def has_add_permission(self, request):
#         return False
#
#     def has_delete_permission(self, request, obj=None):
#         return False
#
# admin.site.register(MigrationRecorder.Migration, MigrationAdmin, app_label=MigrationsConfig.name)
