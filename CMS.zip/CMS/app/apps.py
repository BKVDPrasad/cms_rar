from django.apps import AppConfig


class AppConfig(AppConfig):
    name = 'app'


class MigrationsConfig(AppConfig):
    name = 'migrations'
